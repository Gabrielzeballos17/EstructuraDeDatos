#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{
}

int Vector::Get_tamano()
{
	return tamano;
}
void Vector::Set_tamano(int tam)
{
	tamano=tam;
}
double Vector::Get_vector(int posicion)
{
	return vec[posicion];
}
void Vector::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Vector::LlenoVector()
{
	if(tamano==M-1)
	{return true;}
	else{return false;}
}
bool Vector::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Vector::Llenar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
