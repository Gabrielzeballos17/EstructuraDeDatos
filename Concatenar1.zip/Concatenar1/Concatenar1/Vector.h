#pragma once
#define N 50
#define M 50

class Vector
{
private:
	double vec[N];
	int tamano;
public:
	Vector(void);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	int Get_tamano();
	void Set_tamano(int tam);
	bool LlenoVector();
	bool VacioVector();
	bool Llenar(int poicion ,double elemento);
	
};
